# Legal Notes
Original UI/code by DocumentsTabletopPals. 5E-compatible mechanics from SRD. No proprietary text/stat blocks included.
